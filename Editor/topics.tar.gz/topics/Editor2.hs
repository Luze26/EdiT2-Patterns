import System.Environment( getArgs )
import Data.Char( intToDigit )
import Tree

main :: IO()
main = do
	args <- getArgs
	start (args ++ (createList 10))

start :: [String] -> IO()
start (file:m:args) = do
												writeFile file "[\"Topic\",\"Editor\",\"Section\",\"Editor\"]\n\nscript="
												printTree file True "" $ generate args $ readInt m

generate :: [String] -> Int -> NTree Cell
generate n m = Node ("Root","1","null",[]) $ editorLevel (length n) n n m 0

editorLevel :: Int -> [String] -> [String] -> Int -> Int -> [NTree Cell]
editorLevel _ _ [] _ _ = []
editorLevel nb n (p:ps) m i = Node ("Topic", tId, "1", [ "Topic" ++ strI ]) [ Node ("Editor", eId, tId, [p]) $ sectionLevel eId strI (nb-1) n m 0 ] : editorLevel nb n ps m (i+1)
	where
		strI = show (i+1)
		tId = '1':strI
		eId = tId ++ "1"

sectionLevel :: String -> String -> Int -> [String] -> Int -> Int -> [NTree Cell]
sectionLevel _ _ _ _ 0 _ = []
sectionLevel eId tId nb n m i = Node ("Section", secId, eId, [ "Section" ++ tId ++ strI ]) [ Node ("Editor", e2Id, secId, [n !! e2I]) [] ] : sectionLevel eId tId nb n (m-1) (i+1)
	where
		strI = show (i+1)
		secId = eId ++ strI
		e2Id = secId ++ "1"
		e2I
			| mo >= (readInt tId)-1 = mo+1
			| otherwise = mo
			where 
				mo = mod i nb
		

readInt :: String -> Int
readInt = read

printTree :: String -> Bool -> String -> NTree Cell -> IO()
printTree file noComma tabs (Node cell subtrees) = do
																						appendFile file $ tabs ++ "Node " ++ (show cell) ++ starting
																						printSubTrees file ('\t':tabs) subtrees
																						appendFile file ending
																						where
																							starting
																								| subtrees == [] = " ["
																								| otherwise = " [\n"
																							ending
																								| noComma = "]"
																								| otherwise = "],\n"

printSubTrees :: String -> String -> [NTree Cell] -> IO()
printSubTrees _ _ [] = return ()
printSubTrees file tabs (s:subtrees) = do 
																					printTree file noComma tabs s
																					printSubTrees file tabs subtrees
																					where
																						noComma = subtrees == []


createList :: Int -> [String]
createList 1 = ["e1"]
createList n = ('e' : (show n)) : createList (n-1)
